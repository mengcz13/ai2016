Compiled on Arch Linux.
Use "make", cd ./bin and execute ./main input.txt output.txt

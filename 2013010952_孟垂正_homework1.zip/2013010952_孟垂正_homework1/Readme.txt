编程语言: C++
编译工具: g++ (GCC) 5.3.0
运行环境: Arch Linux(Kernel: x86_64 Linux 4.4.3-1-ARCH)
使用的库: cstdio, cstring, cstdlib
